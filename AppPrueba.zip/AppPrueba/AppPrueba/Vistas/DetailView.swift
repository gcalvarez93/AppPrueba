//
//  DetailView.swift
//  AppPrueba
//
//  Created by Gabriel Castro on 6/2/23.
//

import SwiftUI

struct DetailView: View {
    var body: some View {
        VStack{
            Text("\(UserDataModel.sku)")
            Text("\(UserDataModel.amount)")
            Text("\(UserDataModel.currency)")
        }
           
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView()
    }
}
