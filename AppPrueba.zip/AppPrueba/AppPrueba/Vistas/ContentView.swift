//
//  ContentView.swift
//  AppPrueba
//
//  Created by Gabriel Castro on 6/2/23.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var viewModel: ViewModel = ViewModel()
    
    var body: some View {
        NavigationView {
            List {
                ForEach(viewModel.users, id: \.sku) { user in
                    NavigationLink(destination:DetailView)
                    Text(user.sku)
                }
            }
            .navigationTitle("Usuarios")
        }.onAppear {
            viewModel.getUsers()
        }
    }
}
    
        
    

    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
        
    }

