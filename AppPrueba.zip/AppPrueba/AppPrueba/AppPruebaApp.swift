//
//  AppPruebaApp.swift
//  AppPrueba
//
//  Created by Gabriel Castro on 6/2/23.
//

import SwiftUI

@main
struct AppPruebaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
