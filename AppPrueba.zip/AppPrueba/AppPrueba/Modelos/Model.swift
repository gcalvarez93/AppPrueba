//
//  Model.swift
//  AppPrueba
//
//  Created by Gabriel Castro on 6/2/23.
//

import Foundation


struct UserDataModel: Decodable {
    let sku: String
    let amount: String
    let currency: String

}

struct UserResponseDataModel: Decodable {
    let users: [UserDataModel]
    
    enum CodingKeys: String, CodingKey {
        case sku
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.users = try container.decode([UserDataModel].self, forKey: .sku)
    }
}
