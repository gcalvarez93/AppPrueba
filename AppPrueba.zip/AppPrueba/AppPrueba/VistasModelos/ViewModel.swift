//
//  ViewModel.swift
//  AppPrueba
//
//  Created by Gabriel Castro on 6/2/23.
//

import Foundation

final class ViewModel: ObservableObject {
    
    @Published var users: [UserDataModel] = []
    
    
    func getUsers() {
        let url = URL(string: "https://android-ios-service.herokuapp.com/transactions")
        
        URLSession.shared.dataTask(with: url!) { data, response, error in
            if let _ = error {
                print("Error")
            }
            
            if let data = data,
               let httpResponse = response as? HTTPURLResponse,
               httpResponse.statusCode == 200 {
                let userDataModel = try! JSONDecoder().decode(UserResponseDataModel.self, from: data)
                print("Usuarios \(userDataModel)")
                DispatchQueue.main.async {
                    self.users = userDataModel.users
                }
            }
            
        }.resume()
    }
}
